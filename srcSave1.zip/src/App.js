/* imports */
import './App.css';
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

function Card({ title, onClick, children }) {
  return (
    <div className="card" onClick={onClick} role={onClick ? 'button' : undefined}>
      <div className="card-header">{title}</div>
      <div className="card-body">{children}</div>
    </div>
  );
}

function App() {
  const navigate = useNavigate();
  const [dark, setDark] = useState(false);

  // fake numbers to make the UI feel alive
  const [stats] = useState({
    todayTons: 184,
    trucksOut: 27,
    avgWaitMin: 11,
    forecastTons: 205
  });

  return (
    <div className={`dashboard ${dark ? 'dark' : ''}`}>
      <header className="topbar">
        <h1>MCAi — Material Volume</h1>
        <div className="topbar-actions">
          <button onClick={() => setDark(d => !d)}>{dark ? 'Light' : 'Dark'} mode</button>
        </div>
      </header>

      <main className="grid">
        <Card title="Today’s Volume">
          <h2 className="big">{stats.todayTons} t</h2>
          <p>Last updated 5 min ago</p>
        </Card>

        <Card title="Trucks Out">
          <h2 className="big">{stats.trucksOut}</h2>
          <p>Active dispatches</p>
        </Card>

        <Card title="Avg Wait Time">
          <h2 className="big">{stats.avgWaitMin} min</h2>
          <p>Gate to load</p>
        </Card>

        <Card title="Forecast (Today)">
          <h2 className="big">{stats.forecastTons} t</h2>
          <p>Based on weather + day/time</p>
        </Card>

        <Card title="Upload CSV" onClick={() => navigate('/upload')}>
          <p>Click to upload historical data</p>
        </Card>

        <Card title="Predictions" onClick={() => navigate('/predict')}>
          <p>Run model → see predicted volume</p>
        </Card>

        <Card title="Locations" onClick={() => navigate('/map')}>
          <p>See plant/site volumes on a map</p>
        </Card>

        <Card title="Reports" onClick={() => navigate('/reports')}>
          <p>Export weekly/monthly summaries</p>
        </Card>
      </main>
    </div>
  );
}

export default App;
