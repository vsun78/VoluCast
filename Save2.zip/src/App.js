// src/App.js
import React from "react";
import Bento_5_v4 from "./Bento_5_v4";

export default function App() {
  return <Bento_5_v4 />;
}
