import React, { useEffect, useState } from "react";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer
} from "recharts";

export default function OilBarCard({ weeks = 8 }) {
  const [rows, setRows] = useState(null);

  useEffect(() => {
    (async () => {
      try {
        const r1 = await fetch(`/api/oil/wti-weekly?limit=${weeks}`);
        const r2 = await fetch(`/api/oil/stocks-weekly?limit=${weeks}`);
        if (!r1.ok || !r2.ok) throw new Error("API error");
        const wti = await r1.json(); // [{ period, price }]
        const stk = await r2.json(); // [{ period, stocks }]

        const index = new Map(wti.map(p => [p.period, { period: p.period, wti: p.price }]));
        for (const s of stk) {
          const row = index.get(s.period) || { period: s.period };
          row.stocks = s.stocks;
          index.set(s.period, row);
        }
        const merged = Array.from(index.values())
          .sort((a, b) => a.period.localeCompare(b.period))
          .slice(-weeks)
          .map(r => ({ period: r.period, WTI: r.wti ?? null, Stocks: r.stocks ?? null }));

        setRows(merged.length ? merged : null);
      } catch {
        // fallback demo
        setRows([
          { period: "2025-06-06", WTI: 77.2, Stocks: 430.1 },
          { period: "2025-06-13", WTI: 78.5, Stocks: 428.7 },
          { period: "2025-06-20", WTI: 76.9, Stocks: 431.3 },
          { period: "2025-06-27", WTI: 79.4, Stocks: 427.9 },
          { period: "2025-07-04", WTI: 80.1, Stocks: 426.8 },
          { period: "2025-07-11", WTI: 81.6, Stocks: 425.4 },
          { period: "2025-07-18", WTI: 82.3, Stocks: 424.6 },
          { period: "2025-07-25", WTI: 83.0, Stocks: 426.7 }
        ]);
      }
    })();
  }, [weeks]);

  return (
    <div style={{ height: 120 /* shrink height for tiny tile */ }}>
      <ResponsiveContainer width="100%" height="100%">
        <BarChart
          data={rows || []}
          margin={{ top: 2, right: 4, left: 4, bottom: 0 }}
          barGap={1}
          barCategoryGap="55%"
        >
          {/* keep only a minimal tooltip; everything else hidden */}
          <Tooltip cursor={false} />
          <XAxis dataKey="period" hide />
          <YAxis yAxisId="left" hide domain={["dataMin-2", "dataMax+2"]} />
          <YAxis yAxisId="right" hide orientation="right" domain={["dataMin-10", "dataMax+10"]} />

          <Bar yAxisId="left"  dataKey="WTI"    fill="#0ea5e9" radius={[3,3,0,0]} barSize={5} />
          <Bar yAxisId="right" dataKey="Stocks" fill="#7c3aed" radius={[3,3,0,0]} barSize={5} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
