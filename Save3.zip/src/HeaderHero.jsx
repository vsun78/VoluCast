// src/HeaderHero.jsx
"use client";

import React from "react";
import { VideoText } from "./Components/video-text"; // <- note lowercase path

export default function HeaderHero() {
  return (
    <header className="w-full">
      <div className="mx-auto w-full max-w-[1400px] px-4 pt-4">
        <div className="relative h-[150px] sm:h-[170px] md:h-[190px] rounded-2xl overflow-hidden ring-1 ring-black/5 bg-white shadow-[0_8px_30px_rgba(0,0,0,0.06)]">
          <VideoText
            src="/VoluCastLoop.mp4"
            className="w-full h-full"
            fontSize={26}          // big letters (vw units)
            fontWeight={900}
            fontFamily="'Inter', ui-sans-serif"
            maskPercent={78}       // fill most of the width
            autoPlay
            muted
            loop
            preload="metadata"
          >
            VoluCast
          </VideoText>
        </div>
      </div>
    </header>
  );
}
